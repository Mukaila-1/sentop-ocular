
import React from 'react';
import EyeScan from './components/EyeScan';

function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-slate-800 dark:text-slate-200 p-4">
      <header className="w-full max-w-4xl text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-blue-600 dark:text-blue-400">
          Ocular AI Scan
        </h1>
        <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
          Get an AI-powered preliminary analysis of your eye health.
        </p>
         <p className="mt-2 text-md text-slate-500 dark:text-slate-400">
          Enter a User ID and upload an ID card to begin and save your scan history to your device.
        </p>
      </header>

      <main className="w-full max-w-4xl">
        <EyeScan />
      </main>

      <footer className="w-full max-w-4xl text-center mt-12 p-4 border-t border-slate-200 dark:border-slate-700">
        <p className="text-sm text-red-600 dark:text-red-400 font-semibold">
          Disclaimer: This is not a medical diagnosis.
        </p>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          The analysis provided is for informational purposes only and should not be considered a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.
        </p>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-4">
          &copy; {new Date().getFullYear()} Sentop Solution Limited. All Rights Reserved.
        </p>
      </footer>
    </div>
  );
}

export default App;
