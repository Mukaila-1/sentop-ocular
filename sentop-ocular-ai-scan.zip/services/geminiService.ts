import { GoogleGenAI, Type } from "@google/genai";

type GenerativePart = {
  inlineData: {
    data: string;
    mimeType: string;
  };
};

export type EyeAnalysisResult = {
  analysis: string;
  ocularBbox?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
};

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const model = 'gemini-2.5-flash';

export async function analyzeEyeImage(imagePart: GenerativePart): Promise<EyeAnalysisResult> {
  const prompt = `You are an AI assistant specializing in preliminary ocular health analysis based on images of the human eyeball.
Analyze the provided close-up image of a human eye.

Your task is to:
1.  Identify the primary eyeball in the image. Determine a tight bounding box around the visible ocular area (sclera, iris, pupil). The coordinates must be normalized from 0 to 1, where (0,0) is the top-left corner. If an eye cannot be clearly identified, omit the 'ocularBbox' field from your response.
2.  Focus your analysis strictly on the eyeball itself. Carefully examine the image for any visible, potential areas of concern. This includes, but is not limited to:
    *   **Sclera (the white part):** Look for significant redness, yellowing (jaundice), visible blood vessels, or any unusual growths or spots.
    *   **Iris (the colored part):** Note any unusual spots, discoloration, or irregularities in the pattern.
    *   **Cornea (the transparent outer layer):** Look for any cloudiness, haziness, or visible scratches.
    *   **Pupil (the black center):** Check for irregularities in shape or size (though this can be affected by light).
3.  Provide a summary of your observations in a clear, structured, and neutral tone. Use a bulleted list for your key observations. Do not analyze the surrounding skin, eyelashes, or eyelids unless they directly obstruct the view of the eyeball.
4.  **IMPORTANT**: Start your entire 'analysis' text response with a clear and prominent disclaimer. State that you are an AI, this is not a medical diagnosis, and the user must consult a qualified healthcare professional for any health concerns. Do not offer any diagnosis or treatment advice.
5.  Keep your language easy to understand for a general audience. Avoid overly technical jargon.

Example analysis text format:

***DISCLAIMER: This is an AI-powered analysis and is not a substitute for professional medical advice. Please consult a doctor for any health concerns.***

**Observations of the Eyeball:**
*   Observation about the Sclera...
*   Observation about the Iris...
*   Observation about the Cornea/Pupil...

**General Note:** A concluding sentence reminding them to see a doctor for a proper diagnosis.
`;

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      analysis: {
        type: Type.STRING,
        description: "The detailed textual analysis of the eye, following the specified format."
      },
      ocularBbox: {
        type: Type.OBJECT,
        description: "A bounding box around the ocular area, with normalized coordinates (0-1). Omit if no eye is clearly identifiable.",
        properties: {
          x: { type: Type.NUMBER, description: "Normalized x-coordinate of the top-left corner." },
          y: { type: Type.NUMBER, description: "Normalized y-coordinate of the top-left corner." },
          width: { type: Type.NUMBER, description: "Normalized width of the box." },
          height: { type: Type.NUMBER, description: "Normalized height of the box." }
        },
      }
    }
  };

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: {
            parts: [
                imagePart,
                { text: prompt },
            ]
        },
        config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        }
    });

    if (response && response.text) {
        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr) as EyeAnalysisResult;
        if (typeof parsed.analysis === 'string') {
            return parsed;
        }
    }
    throw new Error("The AI returned an invalid or empty response.");
  } catch (error) {
    console.error("Error analyzing eye image:", error);
    if (error instanceof Error && error.message.includes('permission')) {
        throw new Error("API key is invalid or has insufficient permissions.");
    }
    throw new Error("Failed to communicate with the AI service. Please try again later.");
  }
}