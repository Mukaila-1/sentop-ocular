import React, { useState } from 'react';

interface UserIdInputProps {
  onIdSubmit: (id: string) => void;
}

const UserIdInput: React.FC<UserIdInputProps> = ({ onIdSubmit }) => {
  const [id, setId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (id.trim()) {
      onIdSubmit(id.trim());
    }
  };

  return (
    <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center">
      <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Enter User Identifier</h2>
      <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md">
        Please provide a unique ID to associate with your scan results. This allows you to track your scan history.
      </p>
      <form onSubmit={handleSubmit} className="w-full max-w-sm flex flex-col items-center">
        <label htmlFor="userId" className="sr-only">User ID</label>
        <input
          type="text"
          id="userId"
          value={id}
          onChange={(e) => setId(e.target.value)}
          placeholder="e.g., JohnDoe123"
          className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
          aria-required="true"
        />
        <button
          type="submit"
          disabled={!id.trim()}
          className="mt-6 w-full px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500 disabled:bg-slate-400 disabled:dark:bg-slate-500 disabled:cursor-not-allowed"
        >
          Start Scan
        </button>
      </form>
    </div>
  );
};

export default UserIdInput;
