
import React, { useRef, useState, useEffect } from 'react';
import { WarningIcon } from './icons/WarningIcon';

interface CameraViewIdProps {
    onCapture: (file: File) => void;
    onCancel: () => void;
}

const CameraViewId: React.FC<CameraViewIdProps> = ({ onCapture, onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const constraints: MediaStreamConstraints = {
            video: {
                facingMode: 'environment', // Prefer rear camera for ID cards
                width: { ideal: 1920, max: 4096 },
                height: { ideal: 1080, max: 2160 },
            }
        };
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          streamRef.current = stream;
        }
      } catch (err) {
        console.error("Error accessing camera: ", err);
        if (err instanceof Error) {
            if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
                setError("Camera permission denied. Please allow camera access in your browser settings and refresh the page.");
            } else if (err.name === "OverconstrainedError" || err.name === "ConstraintNotSatisfiedError") {
                // Fallback to default if high resolution fails
                try {
                    const fallbackStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                    if (videoRef.current) {
                        videoRef.current.srcObject = fallbackStream;
                        streamRef.current = fallbackStream;
                    }
                } catch (fallbackErr) {
                    setError("Could not access the camera. Please ensure it is not in use by another application.");
                }
            } else {
                setError("Could not access the camera. Please ensure it is not in use by another application.");
            }
        } else {
            setError("An unknown error occurred while accessing the camera.");
        }
      }
    };
    startCamera();

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      const context = canvas.getContext('2d');
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], `id-capture-${Date.now()}.jpg`, { type: 'image/jpeg' });
            onCapture(file);
          }
        }, 'image/jpeg', 0.95);
      }
    }
  };

  if (error) {
    return (
        <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center">
            <WarningIcon />
            <h3 className="mt-4 text-xl font-semibold text-red-700 dark:text-red-300">Camera Error</h3>
            <p className="mt-2 text-red-600 dark:text-red-400 max-w-md">{error}</p>
            <button
                onClick={onCancel}
                className="mt-6 px-6 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
            >
                Back to Upload
            </button>
        </div>
    );
  }

  return (
    <div className="w-full p-4 sm:p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center">
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Capture ID Card</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-4 text-center">Position your ID card within the rectangle and ensure the text is clear and readable.</p>
        <div className="relative w-full max-w-lg aspect-video bg-slate-900 rounded-lg overflow-hidden shadow-inner">
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover"></video>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-[90%] h-[70%] border-4 border-dashed border-white/70 rounded-lg"></div>
            </div>
            <canvas ref={canvasRef} className="hidden"></canvas>
        </div>
        <div className="flex items-center justify-center gap-6 mt-6 w-full">
            <button
                onClick={onCancel}
                className="px-6 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
            >
                Cancel
            </button>
            <button
                onClick={handleCapture}
                aria-label="Take Picture"
                className="w-20 h-20 bg-white rounded-full p-1.5 shadow-lg flex items-center justify-center group focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500"
            >
                <span className="w-full h-full bg-blue-600 rounded-full group-hover:bg-blue-700 transition-colors"></span>
            </button>
             {/* This invisible button is to balance the flex container */}
            <div className="px-6 py-2 invisible" aria-hidden="true">Cancel</div>
        </div>
    </div>
  );
};

export default CameraViewId;