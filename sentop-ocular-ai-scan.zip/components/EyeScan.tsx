import React, { useState, useCallback, useRef, useEffect } from 'react';
import { analyzeEyeImage, EyeAnalysisResult } from '../services/geminiService';
import { fileToGenerativePart } from '../utils/imageUtils';
import { CameraIcon } from './icons/CameraIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { WarningIcon } from './icons/WarningIcon';
import UserIdInput from './UserIdInput';
import IdCardUploader from './IdCardUploader';
import CameraViewId from './CameraViewId';
import ScanHistory from './ScanHistory';

// Sub-component for uploading an image file or opening the camera
const ImageUploader: React.FC<{ 
    onImageSelect: (file: File) => void; 
    onOpenCamera: () => void; 
    viewHistoryButton?: React.ReactNode;
}> = ({ onImageSelect, onOpenCamera, viewHistoryButton }) => {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      onImageSelect(event.target.files[0]);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
  };

  const handleDrop = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      onImageSelect(event.dataTransfer.files[0]);
    }
  };

  return (
    <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center">
      <div className="w-full flex justify-between items-start mb-4">
        <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200 text-left">Upload or Capture an Eye Image</h2>
        {viewHistoryButton}
      </div>
      <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md text-left w-full">
        For the best results, use a clear, well-lit, close-up photo of one of your eyeballs. Try to get as little of your eyelids or surrounding skin as possible.
      </p>
      <label
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className="w-full flex flex-col items-center justify-center px-6 py-12 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
      >
        <CameraIcon />
        <span className="mt-4 text-blue-600 dark:text-blue-400 font-medium">Click to upload or drag and drop</span>
        <span className="mt-1 text-sm text-slate-500 dark:text-slate-400">PNG, JPG, or WEBP</span>
        <input 
          type="file" 
          className="hidden" 
          accept="image/png, image/jpeg, image/webp"
          onChange={handleFileChange} 
        />
      </label>

      <div className="my-6 flex items-center w-full max-w-sm">
        <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
        <span className="flex-shrink mx-4 text-slate-500 dark:text-slate-400">OR</span>
        <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
      </div>

      <button
        onClick={onOpenCamera}
        className="flex items-center justify-center gap-3 px-6 py-3 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500"
      >
        <CameraIcon />
        <span>Use Camera</span>
      </button>
    </div>
  );
};

// Sub-component for displaying the analysis result
const AnalysisView: React.FC<{ imageUrl: string; analysisResult: EyeAnalysisResult; onNewScan: () => void; onReanalyze: (file: File) => void; }> = ({ imageUrl, analysisResult, onNewScan, onReanalyze }) => {
    const [scale, setScale] = useState(1);
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const imageContainerRef = useRef<HTMLDivElement>(null);
    const imageRef = useRef<HTMLImageElement>(null);
    
    const maxScale = 5;
    const minScale = 1;
    const { analysis, ocularBbox } = analysisResult;

    useEffect(() => {
        // Auto-zoom to the ocular bounding box when an analysis result is available
        const image = imageRef.current;
        const container = imageContainerRef.current;
    
        if (ocularBbox && image && container) {
            const setupView = () => {
                const containerWidth = container.clientWidth;
                const containerHeight = container.clientHeight;
                const imageWidth = image.naturalWidth;
                const imageHeight = image.naturalHeight;
    
                if (imageWidth === 0 || imageHeight === 0) return; // Image not loaded yet
    
                // 1. Calculate the initial scale factor of the image from 'object-contain'
                const containScale = Math.min(containerWidth / imageWidth, containerHeight / imageHeight);
    
                // 2. Define the target area (padded bounding box for context)
                const paddingFactor = 0.4; // 40% total padding (20% on each side)
                const paddedWidth = ocularBbox.width * (1 + paddingFactor);
                const paddedHeight = ocularBbox.height * (1 + paddingFactor);
                const paddedX = Math.max(0, ocularBbox.x - (ocularBbox.width * paddingFactor / 2));
                const paddedY = Math.max(0, ocularBbox.y - (ocularBbox.height * paddingFactor / 2));
                
                const finalPaddedWidth = Math.min(paddedWidth, 1 - paddedX);
                const finalPaddedHeight = Math.min(paddedHeight, 1 - paddedY);
    
                // 3. Calculate the target scale required to make the padded box cover the container
                const targetScaleX = containerWidth / (finalPaddedWidth * imageWidth);
                const targetScaleY = containerHeight / (finalPaddedHeight * imageHeight);
                const targetScale = Math.max(targetScaleX, targetScaleY); // Use max for 'cover' behavior
    
                // 4. The CSS scale is the target scale relative to the initial 'contain' scale
                const cssScale = Math.max(minScale, targetScale / containScale);
                setScale(cssScale);
    
                // 5. Calculate the offset to center the target area
                const bboxCenterXpx = (paddedX + finalPaddedWidth / 2) * imageWidth;
                const bboxCenterYpx = (paddedY + finalPaddedHeight / 2) * imageHeight;
                const imageCenterXpx = imageWidth / 2;
                const imageCenterYpx = imageHeight / 2;
    
                const deltaXpx = imageCenterXpx - bboxCenterXpx;
                const deltaYpx = imageCenterYpx - bboxCenterYpx;
    
                // The required translation is the distance from image center to bbox center,
                // scaled first by 'contain' and then by our additional 'cssScale'.
                const newOffsetX = deltaXpx * containScale * cssScale;
                const newOffsetY = deltaYpx * containScale * cssScale;
                
                setOffset({ x: newOffsetX, y: newOffsetY });
            };
    
            if (image.complete) {
                setupView();
            } else {
                image.onload = setupView;
            }
        } else {
            // Reset view if no bounding box
            setScale(1);
            setOffset({ x: 0, y: 0 });
        }
    }, [analysisResult]);


    const handleZoom = (direction: 'in' | 'out') => {
        setScale(prevScale => {
            const newScale = direction === 'in' ? prevScale * 1.2 : prevScale / 1.2;
            return Math.max(minScale, Math.min(maxScale, newScale));
        });
    };

    const handleMouseDown = (e: React.MouseEvent) => {
        if (scale > 1) {
            setIsDragging(true);
            e.preventDefault();
        }
    };

    const handleMouseUp = () => setIsDragging(false);
    const handleMouseLeave = () => setIsDragging(false);

    const handleMouseMove = (e: React.MouseEvent) => {
        if (isDragging && imageRef.current && imageContainerRef.current) {
            setOffset(prevOffset => {
                const newX = prevOffset.x + e.movementX;
                const newY = prevOffset.y + e.movementY;

                const imgRect = imageRef.current!.getBoundingClientRect();
                const containerRect = imageContainerRef.current!.getBoundingClientRect();

                const clampedX = Math.max(Math.min(newX, (imgRect.width - containerRect.width) / 2), -(imgRect.width - containerRect.width) / 2);
                const clampedY = Math.max(Math.min(newY, (imgRect.height - containerRect.height) / 2), -(imgRect.height - containerRect.height) / 2);

                return { x: clampedX, y: clampedY };
            });
        }
    };
    
    useEffect(() => {
        if (scale === 1) {
            setOffset({ x: 0, y: 0 });
        }
    }, [scale]);

    const handleReanalyze = () => {
        const image = imageRef.current;
        const container = imageContainerRef.current;
        if (!image || !container) return;

        const canvas = document.createElement('canvas');
        const outputSize = Math.min(image.naturalWidth, 2048);
        canvas.width = outputSize;
        canvas.height = outputSize;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const currentWidth = image.clientWidth * scale;
        const currentHeight = image.clientHeight * scale;

        const sx = (image.naturalWidth / 2) - (container.clientWidth / (2 * scale)) - (offset.x / scale) * (image.naturalWidth / image.clientWidth);
        const sy = (image.naturalHeight / 2) - (container.clientHeight / (2 * scale)) - (offset.y / scale) * (image.naturalHeight / image.clientHeight);
        const sWidth = container.clientWidth / scale * (image.naturalWidth / image.clientWidth);
        const sHeight = container.clientHeight / scale * (image.naturalHeight / image.clientHeight);

        ctx.drawImage(
            image,
            sx, sy, sWidth, sHeight,
            0, 0, canvas.width, canvas.height
        );

        canvas.toBlob((blob) => {
            if (blob) {
                const file = new File([blob], `crop-${Date.now()}.jpg`, { type: 'image/jpeg' });
                onReanalyze(file);
            }
        }, 'image/jpeg', 0.95);
    };


    return (
    <div className="w-full p-6 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative">
                <h3 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Your Image</h3>
                <div 
                    ref={imageContainerRef}
                    className="rounded-lg w-full object-cover aspect-video overflow-hidden bg-slate-900 shadow-inner"
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseLeave}
                >
                    <img 
                        ref={imageRef}
                        src={imageUrl} 
                        alt="User's eye for analysis" 
                        className={`w-full h-full object-contain transition-transform duration-100 ${isDragging ? 'cursor-grabbing' : (scale > 1 ? 'cursor-grab' : '')}`}
                        style={{ transform: `scale(${scale}) translate(${offset.x}px, ${offset.y}px)` }}
                        draggable="false"
                    />
                </div>
                <div className="absolute bottom-2 right-2 flex flex-col gap-2">
                    <button onClick={() => handleZoom('in')} className="w-8 h-8 rounded-full bg-black/50 text-white text-xl flex items-center justify-center hover:bg-black/70">+</button>
                    <button onClick={() => handleZoom('out')} className="w-8 h-8 rounded-full bg-black/50 text-white text-xl flex items-center justify-center hover:bg-black/70">-</button>
                </div>
            </div>
            <div>
                <h3 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">AI Analysis</h3>
                <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg max-h-96 overflow-y-auto">
                    <p className="text-slate-600 dark:text-slate-300 whitespace-pre-wrap font-mono text-sm leading-relaxed">{analysis}</p>
                </div>
            </div>
        </div>
        <div className="flex flex-wrap justify-center items-center gap-4 mt-8">
            <button
                onClick={onNewScan}
                className="px-6 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
            >
                Scan Another Image
            </button>
            <button
                onClick={handleReanalyze}
                disabled={scale === 1 && !ocularBbox}
                className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500 disabled:bg-slate-400 disabled:dark:bg-slate-500 disabled:cursor-not-allowed"
            >
                Re-analyze Zoomed Area
            </button>
        </div>
    </div>
    );
};

// Sub-component for the live camera view and capturing a photo
const CameraView: React.FC<{ onCapture: (file: File) => void; onCancel: () => void; }> = ({ onCapture, onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const constraints: MediaStreamConstraints = {
            video: {
                facingMode: 'user',
                width: { ideal: 1920, max: 4096 },
                height: { ideal: 1080, max: 2160 },
            }
        };
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          streamRef.current = stream;
        }
      } catch (err) {
        console.error("Error accessing camera: ", err);
        if (err instanceof Error) {
            if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
                setError("Camera permission denied. Please allow camera access in your browser settings and refresh the page.");
            } else if (err.name === "OverconstrainedError" || err.name === "ConstraintNotSatisfiedError") {
                // Fallback to default if high resolution fails
                try {
                    const fallbackStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
                    if (videoRef.current) {
                        videoRef.current.srcObject = fallbackStream;
                        streamRef.current = fallbackStream;
                    }
                } catch (fallbackErr) {
                    setError("Could not access the camera. Please ensure it is not in use by another application.");
                }
            } else {
                setError("Could not access the camera. Please ensure it is not in use by another application.");
            }
        } else {
            setError("An unknown error occurred while accessing the camera.");
        }
      }
    };
    startCamera();

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      const context = canvas.getContext('2d');
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        // Flip the image horizontally to match the mirrored video feed
        context.translate(canvas.width, 0);
        context.scale(-1, 1);
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], `capture-${Date.now()}.jpg`, { type: 'image/jpeg' });
            onCapture(file);
          }
        }, 'image/jpeg', 0.95);
      }
    }
  };

  if (error) {
    return (
        <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center">
            <WarningIcon />
            <h3 className="mt-4 text-xl font-semibold text-red-700 dark:text-red-300">Camera Error</h3>
            <p className="mt-2 text-red-600 dark:text-red-400 max-w-md">{error}</p>
            <button
                onClick={onCancel}
                className="mt-6 px-6 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
            >
                Back to Upload
            </button>
        </div>
    );
  }

  return (
    <div className="w-full p-4 sm:p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center">
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Live Camera</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-4 text-center">The camera is zoomed in to focus on your eye. Position your eye within the oval and hold still.</p>
        <div className="relative w-full max-w-lg aspect-video bg-slate-900 rounded-lg overflow-hidden shadow-inner">
            <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover" 
                style={{ transform: 'scaleX(-1) scale(2.5)' }}>
            </video>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-[60%] h-[40%] border-4 border-dashed border-white/70 rounded-[50%]"></div>
            </div>
            <canvas ref={canvasRef} className="hidden"></canvas>
        </div>
        <div className="flex items-center justify-center gap-6 mt-6 w-full">
            <button
                onClick={onCancel}
                className="px-6 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
            >
                Cancel
            </button>
            <button
                onClick={handleCapture}
                aria-label="Take Picture"
                className="w-20 h-20 bg-white rounded-full p-1.5 shadow-lg flex items-center justify-center group focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500"
            >
                <span className="w-full h-full bg-red-600 rounded-full group-hover:bg-red-700 transition-colors"></span>
            </button>
             {/* This invisible button is to balance the flex container */}
            <div className="px-6 py-2 invisible" aria-hidden="true">Cancel</div>
        </div>
    </div>
  );
};


// Main component managing the state and views
const EyeScan: React.FC = () => {
  type View = 'userIdInput' | 'idCardUploader' | 'idCamera' | 'uploader' | 'camera' | 'preview' | 'loading' | 'analysis' | 'error' | 'history';
  
  const [view, setView] = useState<View>('userIdInput');
  const [userId, setUserId] = useState<string | null>(null);
  const [idCardFile, setIdCardFile] = useState<File | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<EyeAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasHistory, setHasHistory] = useState(false);

  // Effect to clean up object URLs to prevent memory leaks
  useEffect(() => {
    return () => {
      if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
      }
    };
  }, [imageUrl]);

  // Effect to check if user has scan history
  useEffect(() => {
    if (view === 'uploader' && userId) {
        try {
            const key = `ocular_scan_results_${userId}`;
            const existingDataRaw = localStorage.getItem(key);
            if (existingDataRaw) {
                const existingData = JSON.parse(existingDataRaw);
                setHasHistory(Array.isArray(existingData) && existingData.length > 0);
            } else {
                setHasHistory(false);
            }
        } catch (e) {
            console.warn("Could not check scan history:", e);
            setHasHistory(false);
        }
    }
  }, [view, userId]);


  const handleIdSubmit = (id: string) => {
    setUserId(id);
    setView('idCardUploader');
  };
  
  const handleIdCardSelect = (file: File) => {
    setIdCardFile(file);
    setView('uploader');
  };

  const handleImageSelect = (file: File) => {
    if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
    }
    setImageFile(file);
    setImageUrl(URL.createObjectURL(file));
    setAnalysisResult(null);
    setError(null);
    setView('preview');
  };

  const performAnalysis = useCallback(async (fileToAnalyze: File) => {
    setView('loading');
    setError(null);
    setAnalysisResult(null);

    try {
        const imagePart = await fileToGenerativePart(fileToAnalyze);
        const result = await analyzeEyeImage(imagePart);
        
        // Save the result to local storage
        if (userId) {
            const newRecord = {
                analysis: result.analysis,
                timestamp: new Date().toISOString(),
                // idCardFile is available here if needed for future use
            };
            try {
                const key = `ocular_scan_results_${userId}`;
                const existingDataRaw = localStorage.getItem(key);
                const existingData = existingDataRaw ? JSON.parse(existingDataRaw) : [];
                localStorage.setItem(key, JSON.stringify([...existingData, newRecord]));
            } catch (storageError) {
                console.warn("Could not save analysis to local storage:", storageError);
                // Non-critical error, so we don't need to show it to the user.
            }
        }
        
        if (fileToAnalyze !== imageFile) {
            if (imageUrl) {
                URL.revokeObjectURL(imageUrl);
            }
            setImageUrl(URL.createObjectURL(fileToAnalyze));
        }
        
        setImageFile(fileToAnalyze);
        setAnalysisResult(result);
        setView('analysis');
    } catch (err) {
        console.error(err);
        setError(err instanceof Error ? err.message : 'An unknown error occurred during analysis.');
        setView('error');
    }
  }, [imageFile, imageUrl, userId]);


  const resetSession = () => {
    if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
    }
    setImageFile(null);
    setImageUrl(null);
    setAnalysisResult(null);
    setError(null);
    setUserId(null);
    setIdCardFile(null);
    setView('userIdInput');
  };
  
  const resetScan = () => {
    if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
    }
    setImageFile(null);
    setImageUrl(null);
    setAnalysisResult(null);
    setError(null);
    setView('uploader');
  }

  // Render logic based on the current view state
  switch(view) {
    case 'userIdInput':
        return <UserIdInput onIdSubmit={handleIdSubmit} />;

    case 'idCardUploader':
        return <IdCardUploader 
            onIdCardSelect={handleIdCardSelect} 
            onOpenCamera={() => setView('idCamera')}
            onBack={() => {
                setUserId(null);
                setView('userIdInput');
            }}
        />;

    case 'idCamera':
        return <CameraViewId 
            onCapture={handleIdCardSelect} 
            onCancel={() => setView('idCardUploader')}
        />;

    case 'uploader':
      return <ImageUploader 
        onImageSelect={handleImageSelect} 
        onOpenCamera={() => setView('camera')}
        viewHistoryButton={
            hasHistory ? (
                <button
                    onClick={() => setView('history')}
                    className="px-4 py-2 text-sm bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200 font-semibold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors whitespace-nowrap"
                >
                    View Scan History
                </button>
            ) : undefined
        }
      />;

    case 'camera':
      return <CameraView onCapture={handleImageSelect} onCancel={resetScan} />;
    
    case 'preview':
      if (imageUrl && imageFile) {
        return (
            <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center">
                <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Image Preview</h2>
                <img src={imageUrl} alt="Eye preview" className="max-h-64 rounded-lg mb-6 shadow-md" />
                <div className="flex items-center gap-4">
                    <button
                        onClick={resetScan}
                        className="px-6 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
                    >
                        Change Image
                    </button>
                    <button
                        onClick={() => performAnalysis(imageFile)}
                        className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500"
                    >
                        Analyze Eyes
                    </button>
                </div>
            </div>
        );
      }
      resetSession();
      return null;

    case 'loading':
      return (
        <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center">
          <SpinnerIcon />
          <p className="mt-4 text-lg font-medium text-slate-600 dark:text-slate-300">AI is analyzing your image...</p>
          <p className="text-sm text-slate-500 dark:text-slate-400">This may take a moment.</p>
        </div>
      );
      
    case 'analysis':
      if (analysisResult && imageUrl && imageFile) {
        return <AnalysisView 
            imageUrl={imageUrl} 
            analysisResult={analysisResult} 
            onNewScan={resetScan} 
            onReanalyze={(croppedFile) => performAnalysis(croppedFile)}
        />;
      }
      setError('Failed to display the analysis result.');
      setView('error');
      return null;

    case 'history':
        if (userId) {
            return <ScanHistory userId={userId} onBack={() => setView('uploader')} />
        }
        // Fallback if userId is somehow null
        setView('uploader');
        return null;

    case 'error':
        return (
            <div className="w-full p-8 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-xl shadow-lg flex flex-col items-center text-center">
                <WarningIcon />
                <h3 className="mt-4 text-xl font-semibold text-red-700 dark:text-red-300">Analysis Failed</h3>
                <p className="mt-2 text-red-600 dark:text-red-400">{error}</p>
                <button
                    onClick={imageFile ? () => performAnalysis(imageFile) : resetSession}
                    className="mt-6 px-6 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors"
                >
                    {imageFile ? 'Try Again' : 'Start Over'}
                </button>
            </div>
        );

    default:
        resetSession();
        return null;
  }
};

export default EyeScan;