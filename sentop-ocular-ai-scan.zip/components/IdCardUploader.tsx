
import React from 'react';
import { CameraIcon } from './icons/CameraIcon';
import { IdCardIcon } from './icons/IdCardIcon';

interface IdCardUploaderProps {
    onIdCardSelect: (file: File) => void;
    onOpenCamera: () => void;
    onBack: () => void;
}

const IdCardUploader: React.FC<IdCardUploaderProps> = ({ onIdCardSelect, onOpenCamera, onBack }) => {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      onIdCardSelect(event.target.files[0]);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
  };

  const handleDrop = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      onIdCardSelect(event.dataTransfer.files[0]);
    }
  };

  return (
    <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center">
      <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Upload Your ID Card</h2>
      <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md">
        Please provide a clear, readable image of your ID card. This is for verification purposes before the scan.
      </p>
      <label
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className="w-full flex flex-col items-center justify-center px-6 py-12 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
      >
        <IdCardIcon />
        <span className="mt-4 text-blue-600 dark:text-blue-400 font-medium">Click to upload or drag and drop</span>
        <span className="mt-1 text-sm text-slate-500 dark:text-slate-400">PNG, JPG, or WEBP</span>
        <input 
          type="file" 
          className="hidden" 
          accept="image/png, image/jpeg, image/webp"
          onChange={handleFileChange} 
        />
      </label>

      <div className="my-6 flex items-center w-full max-w-sm">
        <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
        <span className="flex-shrink mx-4 text-slate-500 dark:text-slate-400">OR</span>
        <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
      </div>
      
      <div className="flex items-center gap-4">
        <button
            onClick={onBack}
            className="px-6 py-3 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
        >
            Back
        </button>

        <button
            onClick={onOpenCamera}
            className="flex items-center justify-center gap-3 px-6 py-3 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-blue-500"
        >
            <CameraIcon />
            <span>Use Camera</span>
        </button>
      </div>

    </div>
  );
};

export default IdCardUploader;
