import React, { useState, useEffect } from 'react';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

type ScanRecord = {
    analysis: string;
    timestamp: string; // ISO string
};

interface ScanHistoryProps {
    userId: string;
    onBack: () => void;
}

const ScanHistory: React.FC<ScanHistoryProps> = ({ userId, onBack }) => {
    const [history, setHistory] = useState<ScanRecord[]>([]);
    const [loading, setLoading] = useState(true);
    const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

    useEffect(() => {
        try {
            const key = `ocular_scan_results_${userId}`;
            const dataRaw = localStorage.getItem(key);
            if (dataRaw) {
                const data = JSON.parse(dataRaw) as ScanRecord[];
                // Sort by most recent first
                data.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
                setHistory(data);
            }
        } catch (error) {
            console.error("Failed to load or parse scan history:", error);
        } finally {
            setLoading(false);
        }
    }, [userId]);

    const formatDate = (isoString: string) => {
        return new Date(isoString).toLocaleString(undefined, {
            dateStyle: 'long',
            timeStyle: 'short'
        });
    };

    const handleToggle = (index: number) => {
        setExpandedIndex(expandedIndex === index ? null : index);
    };

    if (loading) {
        return (
            <div className="w-full p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex justify-center">
                <SpinnerIcon />
            </div>
        );
    }
    
    return (
        <div className="w-full p-6 sm:p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200">Scan History for "{userId}"</h2>
                <button
                    onClick={onBack}
                    className="px-4 py-2 bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
                >
                    Back
                </button>
            </div>
            {history.length === 0 ? (
                <p className="text-center text-slate-500 dark:text-slate-400 py-8">No scan history found for this user.</p>
            ) : (
                <div className="space-y-3">
                    {history.map((record, index) => (
                        <div key={index} className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
                            <button
                                onClick={() => handleToggle(index)}
                                className="w-full flex justify-between items-center p-4 text-left bg-slate-50 dark:bg-slate-700/50 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                                aria-expanded={expandedIndex === index}
                                aria-controls={`scan-content-${index}`}
                            >
                                <span className="font-medium text-slate-800 dark:text-slate-200">{formatDate(record.timestamp)}</span>
                                <ChevronDownIcon isExpanded={expandedIndex === index} />
                            </button>
                            {expandedIndex === index && (
                                <div id={`scan-content-${index}`} className="p-4 bg-white dark:bg-slate-800">
                                    <h3 className="font-semibold mb-2 text-slate-600 dark:text-slate-300">Analysis Details:</h3>
                                    <p className="text-slate-600 dark:text-slate-300 whitespace-pre-wrap font-mono text-sm leading-relaxed">{record.analysis}</p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ScanHistory;