
import React from 'react';

export const IdCardIcon: React.FC = () => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        className="w-12 h-12 text-slate-400 dark:text-slate-500" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        strokeWidth="1.5"
        stroke="currentColor" 
        fill="none" 
        strokeLinecap="round" 
        strokeLinejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <path d="M3 5m0 3a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3z" />
        <path d="M9 10m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
        <path d="M15 8l2 0" />
        <path d="M15 12l2 0" />
        <path d="M7 16l10 0" />
    </svg>
);
